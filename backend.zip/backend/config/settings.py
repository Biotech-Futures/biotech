from pathlib import Path
from datetime import timedelta
from urllib.parse import quote
from decouple import config, Csv

BASE_DIR = Path(__file__).resolve().parent.parent


def env_bool(value):
    value = str(value).strip().lower()
    if value in {"1", "true", "t", "yes", "y", "on", "debug"}:
        return True
    if value in {"0", "false", "f", "no", "n", "off", "release", "prod", "production", ""}:
        return False
    raise ValueError(f"Invalid truth value: {value}")


def build_redis_url(*, host, port, db, password="", use_ssl=False):
    scheme = "rediss" if use_ssl else "redis"
    credentials = f":{quote(password)}@" if password else ""
    return f"{scheme}://{credentials}{host}:{port}/{db}"

SECRET_KEY = config("DJANGO_SECRET_KEY", default="dev-only-not-for-production")
DEBUG = config("DEBUG", default="true", cast=env_bool)
ALLOWED_HOSTS = config("ALLOWED_HOSTS", default="localhost,127.0.0.1", cast=Csv())

INSTALLED_APPS = [
    "django.contrib.admin",
    "django.contrib.auth",
    "django.contrib.contenttypes",
    "django.contrib.sessions",
    "django.contrib.messages",
    "django.contrib.staticfiles",
    'apps.users',
    'apps.groups',
    'apps.chat',
    'apps.resources',
    'apps.announcements',
    'apps.audit',
    'apps.integrations',
    'apps.dashboard',
    'apps.events',
    'apps.user_sessions',
    'apps.matching_runtime',
    'apps.tasks',
    'apps.workshops',
    'apps.certificates',
    'apps.services',
    'matching',
    'drf_spectacular',
    'rest_framework',
    'django_filters',
    'drf_spectacular_sidecar',
    'corsheaders',
    'channels',
    'storages',
]

# Azure Blob Storage
AZURE_ACCOUNT_NAME = config("AZURE_ACCOUNT_NAME", default="")
AZURE_ACCOUNT_KEY = config("AZURE_ACCOUNT_KEY", default="")
AZURE_CONTAINER = config("AZURE_CONTAINER", default="media")
AZURE_CUSTOM_DOMAIN = "btfuturesblobstorage.blob.core.windows.net"
DEFAULT_FILE_STORAGE = "storages.backends.azure_storage.AzureStorage"
MEDIA_URL = f"https://{AZURE_CUSTOM_DOMAIN}/{AZURE_CONTAINER}/"

AUTH_USER_MODEL = 'users.User'

REDIS_HOST = config("REDIS_HOST", default="127.0.0.1")
REDIS_PORT = config("REDIS_PORT", default=6379, cast=int)
REDIS_PASSWORD = config("REDIS_PASSWORD", default="")
REDIS_USE_SSL = config("REDIS_USE_SSL", default="false", cast=env_bool)
REDIS_CHANNEL_DB = config("REDIS_CHANNEL_DB", default=1, cast=int)
REDIS_CELERY_BROKER_DB = config("REDIS_CELERY_BROKER_DB", default=2, cast=int)
REDIS_CELERY_RESULT_DB = config("REDIS_CELERY_RESULT_DB", default=3, cast=int)

CHANNEL_REDIS_URL = config(
    "CHANNEL_REDIS_URL",
    default=build_redis_url(
        host=REDIS_HOST,
        port=REDIS_PORT,
        db=REDIS_CHANNEL_DB,
        password=REDIS_PASSWORD,
        use_ssl=REDIS_USE_SSL,
    ),
)

CELERY_BROKER_URL = config(
    "CELERY_BROKER_URL",
    default=build_redis_url(
        host=REDIS_HOST,
        port=REDIS_PORT,
        db=REDIS_CELERY_BROKER_DB,
        password=REDIS_PASSWORD,
        use_ssl=REDIS_USE_SSL,
    ),
)

CELERY_RESULT_BACKEND = config(
    "CELERY_RESULT_BACKEND",
    default=build_redis_url(
        host=REDIS_HOST,
        port=REDIS_PORT,
        db=REDIS_CELERY_RESULT_DB,
        password=REDIS_PASSWORD,
        use_ssl=REDIS_USE_SSL,
    ),
)

# REST Framework with Django Session Authentication
REST_FRAMEWORK = {
    'DEFAULT_AUTHENTICATION_CLASSES': (
        'rest_framework.authentication.SessionAuthentication',
    ),
    'DEFAULT_PERMISSION_CLASSES': (
        'rest_framework.permissions.IsAuthenticated',
    ),
    'DEFAULT_SCHEMA_CLASS': 'drf_spectacular.openapi.AutoSchema',
    'DEFAULT_FILTER_BACKENDS': ['django_filters.rest_framework.DjangoFilterBackend'],
    'DEFAULT_PAGINATION_CLASS': 'rest_framework.pagination.PageNumberPagination',
    'PAGE_SIZE': 20,
}



SPECTACULAR_SETTINGS = {
    'TITLE': 'BIOTech Futures Mentoring Platform API',
    'DESCRIPTION': 'API Documentation for the New BIOTech Futures Mentoring Platform',
    'VERSION': '1.0.0',
    'SERVE_INCLUDE_SCHEMA': False,
}

MIDDLEWARE = [
    "django.middleware.security.SecurityMiddleware",
    "corsheaders.middleware.CorsMiddleware",
    "django.contrib.sessions.middleware.SessionMiddleware",
    "django.middleware.common.CommonMiddleware",
    "django.middleware.csrf.CsrfViewMiddleware",
    "django.contrib.auth.middleware.AuthenticationMiddleware",
    "apps.user_sessions.middleware.SessionTrackingMiddleware",
    "django.contrib.messages.middleware.MessageMiddleware",
    "django.middleware.clickjacking.XFrameOptionsMiddleware",
]

ROOT_URLCONF = "config.urls"

TEMPLATES = [
    {
        "BACKEND": "django.template.backends.django.DjangoTemplates",
        "DIRS": [],
        "APP_DIRS": True,
        "OPTIONS": {
            "context_processors": [
                "django.template.context_processors.request",
                "django.contrib.auth.context_processors.auth",
                "django.contrib.messages.context_processors.messages",
            ],
        },
    },
]

WSGI_APPLICATION = "config.wsgi.application"
ASGI_APPLICATION = "config.asgi.application"

# Database — local PostgreSQL for development
DATABASES = {
    "default": {
        "ENGINE": "django.db.backends.postgresql",
        "NAME": config("DB_NAME", default="postgres"),
        "USER": config("DB_USER", default="postgres"),
        "PASSWORD": config("DB_PASSWORD", default=""),
        "HOST": config("DB_HOST", default="127.0.0.1"),
        "PORT": config("DB_PORT", default="5432"),
        "OPTIONS": {
            "sslmode": config("DB_SSLMODE", default="require"),
            "connect_timeout": config("DB_CONNECT_TIMEOUT", default=5, cast=int),
        },
        "CONN_MAX_AGE": 0,
    }
}

AUTH_PASSWORD_VALIDATORS = [
    {"NAME": "django.contrib.auth.password_validation.UserAttributeSimilarityValidator"},
    {"NAME": "django.contrib.auth.password_validation.MinimumLengthValidator"},
    {"NAME": "django.contrib.auth.password_validation.CommonPasswordValidator"},
    {"NAME": "django.contrib.auth.password_validation.NumericPasswordValidator"},
]

LANGUAGE_CODE = "en-us"
TIME_ZONE = "UTC"
USE_I18N = True
USE_TZ = True

CHANNEL_LAYERS = {
    "default": {
        "BACKEND": "channels_redis.core.RedisChannelLayer",
        "CONFIG": {
            "hosts": [CHANNEL_REDIS_URL],
        },
    }
}

CELERY_ACCEPT_CONTENT = ["json"]
CELERY_TASK_SERIALIZER = "json"
CELERY_RESULT_SERIALIZER = "json"
CELERY_TIMEZONE = TIME_ZONE
CELERY_BROKER_CONNECTION_RETRY_ON_STARTUP = True

# Email
EMAIL_BACKEND = "django.core.mail.backends.smtp.EmailBackend"
EMAIL_HOST = config("EMAIL_HOST", default="sandbox.smtp.mailtrap.io")
EMAIL_PORT = config("EMAIL_PORT", default=2525, cast=int)
EMAIL_USE_TLS = config("EMAIL_USE_TLS", default="true", cast=env_bool)
EMAIL_HOST_USER = config("EMAIL_HOST_USER", default="")
EMAIL_HOST_PASSWORD = config("EMAIL_HOST_PASSWORD", default="")
STATIC_URL = "static/"
DEFAULT_AUTO_FIELD = "django.db.models.BigAutoField"

CORS_ALLOWED_ORIGINS = config(
    "CORS_ALLOWED_ORIGINS",
    default="http://localhost:5173,http://127.0.0.1:5173,http://localhost:3000",
    cast=Csv()
)
CORS_ALLOW_CREDENTIALS = True

SESSION_COOKIE_NAME = 'sessionid'
SESSION_COOKIE_AGE = 86400
SESSION_COOKIE_HTTPONLY = True
SESSION_COOKIE_SECURE = False
SESSION_COOKIE_SAMESITE = 'Lax'
SESSION_COOKIE_DOMAIN = None
SESSION_SAVE_EVERY_REQUEST = False

CSRF_COOKIE_HTTPONLY = False
CSRF_COOKIE_SAMESITE = 'Lax'
CSRF_COOKIE_SECURE = False
CSRF_TRUSTED_ORIGINS = config(
    "CSRF_TRUSTED_ORIGINS",
    default="http://localhost:5173,http://127.0.0.1:5173",
    cast=Csv()
)

MAGIC_LINK_REDIRECT_URL = config("MAGIC_LINK_REDIRECT_URL", default="http://localhost:5173/#/auth/callback")
LOGIN_REDIRECT_URL = config("LOGIN_REDIRECT_URL", default="http://localhost:5173/auth/callback")
BACKEND_URL = config("BACKEND_URL", default="http://localhost:8000")
MAILTRAP_TOKEN = config("MAILTRAP_TOKEN", default="")
